import Cocoa

var greeting = "Hello, playground"


var numbers = {(s1: Int , s2: Int ) -> Int in return s1 * s2}
print(numbers(5,10))
